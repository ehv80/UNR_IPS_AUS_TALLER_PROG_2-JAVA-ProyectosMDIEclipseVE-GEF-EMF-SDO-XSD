package mdi;

public class EjecutaMdi {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Mdi m= new Mdi();
		m.setVisible(true);

	}

}
