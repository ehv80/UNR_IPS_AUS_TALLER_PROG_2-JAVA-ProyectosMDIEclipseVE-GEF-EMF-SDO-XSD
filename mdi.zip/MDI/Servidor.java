package mdi;


import java.awt.Dimension;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.UnknownHostException;

import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;

public class Servidor extends JInternalFrame {

	private static final long serialVersionUID = 1L;
	private ServerSocket servidor = null;
	private JPanel jContentPane = null;
	private JLabel jPuerto = null;
	private JLabel jMensajeRecibido = null;
	private JTextField jtextPuerto = null;
	private JButton jAceptar = null;
	private JButton jSalir = null;
	private JDesktopPane panel = null;
	private JComboBox jComboBox = null;
	private ThreadServidor thread;
	/**
	 * This is the default constructor
	 */
	public Servidor(JDesktopPane j) {
		super();
		panel = j;
		initialize();
	}

	private void centra () {
		Dimension j = panel.getSize();
		this.setLocation((j.width-this.getWidth())/2,
				(j.height-this.getHeight())/2);
	}

	private void initialize() {
		this.setSize(427, 251);
		this.setMaximizable(true);
		this.setClosable(true);
		centra();
		this.setContentPane(getJContentPane());
		this.setTitle("Servidor");
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jMensajeRecibido = new JLabel();
			jMensajeRecibido.setBounds(new java.awt.Rectangle(21,91,145,24));
			jMensajeRecibido.setFont(new java.awt.Font("Dialog", java.awt.Font.BOLD, 14));
			jMensajeRecibido.setText("Mensajes recibidos:");
			jPuerto = new JLabel();
			jPuerto.setBounds(new java.awt.Rectangle(22,15,145,24));
			jPuerto.setFont(new java.awt.Font("Dialog", java.awt.Font.BOLD, 14));
			jPuerto.setText("Puerto:");
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(jPuerto, null);
			jContentPane.add(jMensajeRecibido, null);
			jContentPane.add(getJtextPuerto(), null);
			jContentPane.add(getJAceptar(), null);
			jContentPane.add(getJSalir(), null);
			jContentPane.add(getJComboBox(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jTextField	
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJtextPuerto() {
		if (jtextPuerto == null) {
			jtextPuerto = new JTextField();
			jtextPuerto.setBounds(new java.awt.Rectangle(189,15,205,24));
		}
		return jtextPuerto;
	}

	/**
	 * This method initializes jAceptar	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJAceptar() {
		if (jAceptar == null) {
			jAceptar = new JButton();
			jAceptar.setBounds(new java.awt.Rectangle(86,176,79,24));
			jAceptar.setText("Iniciar");
			jAceptar.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					if (servidor == null) {
						try {
							int puerto = new Integer(jtextPuerto.getText()).intValue();
							servidor = new ServerSocket(puerto);
							thread = new ThreadServidor(servidor, jComboBox);
							thread.setDaemon(true);
							thread.start();
						} catch (UnknownHostException e1) {
							JOptionPane.showMessageDialog(null,"Servidor Inexistente");
						} catch (IOException e1) {
							JOptionPane.showMessageDialog(null,"Servidor Inaccesible");
						} catch (NumberFormatException e1) {
							JOptionPane.showMessageDialog(null,"El puerto debe ser un n�mero");
						}
					}
					
				}
			});
		}
		return jAceptar;
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJSalir() {
		if (jSalir == null) {
			jSalir = new JButton();
			jSalir.setBounds(new java.awt.Rectangle(251,176,79,24));
			jSalir.setText("Salir");
		}
		return jSalir;
	}

	/**
	 * This method initializes jComboBox	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getJComboBox() {
		if (jComboBox == null) {
			jComboBox = new JComboBox();
			jComboBox.setBounds(new java.awt.Rectangle(187,91,207,24));
		}
		return jComboBox;
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"
