/**
 * Insert the type's description here.
 * Creation date: (2/25/2002 4:00:31 PM)
 * @author: 
 */
class BasicSwingComponentsBundled {
	private javax.swing.JButton ivjJButton1 = null;
	private javax.swing.JCheckBox ivjJCheckBox1 = null;
	private javax.swing.JComboBox ivjJComboBox1 = null;
	private javax.swing.JFrame ivjJFrame1 = null;
	private javax.swing.JPanel ivjJFrameContentPane = null;
	private javax.swing.JLabel ivjJLabel1 = null;
	private javax.swing.JPasswordField ivjJPasswordField1 = null;
	private javax.swing.JProgressBar ivjJProgressBar1 = null;
	private javax.swing.JRadioButton ivjJRadioButton1 = null;
	private javax.swing.JScrollBar ivjJScrollBar1 = null;
	private javax.swing.JSlider ivjJSlider1 = null;
	private javax.swing.JTextArea ivjJTextArea1 = null;
	private javax.swing.JTextField ivjJTextField1 = null;
	private javax.swing.JToggleButton ivjJToggleButton1 = null;
public BasicSwingComponentsBundled() {
	super();
	initialize();
}
/**
 * Return the JButton1 property value.
 * @return javax.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JButton getJButton1() {
	if (ivjJButton1 == null) {
		try {
			ivjJButton1 = new javax.swing.JButton();
			ivjJButton1.setName("JButton1"); //$NON-NLS-1$
			ivjJButton1.setText(Messages.getString("JButton_2")); //$NON-NLS-1$
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjJButton1;
}
/**
 * Return the JCheckBox1 property value.
 * @return javax.swing.JCheckBox
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JCheckBox getJCheckBox1() {
	if (ivjJCheckBox1 == null) {
		try {
			ivjJCheckBox1 = new javax.swing.JCheckBox();
			ivjJCheckBox1.setName("JCheckBox1"); //$NON-NLS-1$
			ivjJCheckBox1.setText(Messages.getString("JCheckBox_4")); //$NON-NLS-1$
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjJCheckBox1;
}
/**
 * Return the JComboBox1 property value.
 * @return javax.swing.JComboBox
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JComboBox getJComboBox1() {
	if (ivjJComboBox1 == null) {
		try {
			ivjJComboBox1 = new javax.swing.JComboBox();
			ivjJComboBox1.setName("JComboBox1"); //$NON-NLS-1$
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjJComboBox1;
}
/**
 * Return the JFrame1 property value.
 * @return javax.swing.JFrame
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JFrame getJFrame1() {
	if (ivjJFrame1 == null) {
		try {
			ivjJFrame1 = new javax.swing.JFrame();
			ivjJFrame1.setName("JFrame1"); //$NON-NLS-1$
			ivjJFrame1.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
			ivjJFrame1.setBounds(45, 25, 317, 273);
			ivjJFrame1.setTitle(Messages.getString("BasicSwingComponents_7")); //$NON-NLS-1$
			getJFrame1().setContentPane(getJFrameContentPane());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjJFrame1;
}
/**
 * Return the JFrameContentPane property value.
 * @return javax.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JPanel getJFrameContentPane() {
	if (ivjJFrameContentPane == null) {
		try {
			ivjJFrameContentPane = new javax.swing.JPanel();
			ivjJFrameContentPane.setName("JFrameContentPane"); //$NON-NLS-1$
			ivjJFrameContentPane.setLayout(new java.awt.FlowLayout());
			getJFrameContentPane().add(getJButton1(), getJButton1().getName());
			getJFrameContentPane().add(getJCheckBox1(), getJCheckBox1().getName());
			getJFrameContentPane().add(getJRadioButton1(), getJRadioButton1().getName());
			getJFrameContentPane().add(getJToggleButton1(), getJToggleButton1().getName());
			getJFrameContentPane().add(getJLabel1(), getJLabel1().getName());
			getJFrameContentPane().add(getJTextField1(), getJTextField1().getName());
			getJFrameContentPane().add(getJPasswordField1(), getJPasswordField1().getName());
			getJFrameContentPane().add(getJTextArea1(), getJTextArea1().getName());
			getJFrameContentPane().add(getJSlider1(), getJSlider1().getName());
			getJFrameContentPane().add(getJScrollBar1(), getJScrollBar1().getName());
			getJFrameContentPane().add(getJComboBox1(), getJComboBox1().getName());
			getJFrameContentPane().add(getJProgressBar1(), getJProgressBar1().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjJFrameContentPane;
}
/**
 * Return the JLabel1 property value.
 * @return javax.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JLabel getJLabel1() {
	if (ivjJLabel1 == null) {
		try {
			ivjJLabel1 = new javax.swing.JLabel();
			ivjJLabel1.setName("JLabel1"); //$NON-NLS-1$
			ivjJLabel1.setText(Messages.getString("JLabel_10")); //$NON-NLS-1$
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjJLabel1;
}
/**
 * Return the JPasswordField1 property value.
 * @return javax.swing.JPasswordField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JPasswordField getJPasswordField1() {
	if (ivjJPasswordField1 == null) {
		try {
			ivjJPasswordField1 = new javax.swing.JPasswordField();
			ivjJPasswordField1.setName("JPasswordField1"); //$NON-NLS-1$
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjJPasswordField1;
}
/**
 * Return the JProgressBar1 property value.
 * @return javax.swing.JProgressBar
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JProgressBar getJProgressBar1() {
	if (ivjJProgressBar1 == null) {
		try {
			ivjJProgressBar1 = new javax.swing.JProgressBar();
			ivjJProgressBar1.setName("JProgressBar1"); //$NON-NLS-1$
			ivjJProgressBar1.setValue(50);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjJProgressBar1;
}
/**
 * Return the JRadioButton1 property value.
 * @return javax.swing.JRadioButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JRadioButton getJRadioButton1() {
	if (ivjJRadioButton1 == null) {
		try {
			ivjJRadioButton1 = new javax.swing.JRadioButton();
			ivjJRadioButton1.setName("JRadioButton1"); //$NON-NLS-1$
			ivjJRadioButton1.setText(Messages.getString("JRadioButton_14")); //$NON-NLS-1$
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjJRadioButton1;
}
/**
 * Return the JScrollBar1 property value.
 * @return javax.swing.JScrollBar
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JScrollBar getJScrollBar1() {
	if (ivjJScrollBar1 == null) {
		try {
			ivjJScrollBar1 = new javax.swing.JScrollBar();
			ivjJScrollBar1.setName("JScrollBar1"); //$NON-NLS-1$
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjJScrollBar1;
}
/**
 * Return the JSlider1 property value.
 * @return javax.swing.JSlider
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JSlider getJSlider1() {
	if (ivjJSlider1 == null) {
		try {
			ivjJSlider1 = new javax.swing.JSlider();
			ivjJSlider1.setName("JSlider1"); //$NON-NLS-1$
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjJSlider1;
}
/**
 * Return the JTextArea1 property value.
 * @return javax.swing.JTextArea
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JTextArea getJTextArea1() {
	if (ivjJTextArea1 == null) {
		try {
			ivjJTextArea1 = new javax.swing.JTextArea();
			ivjJTextArea1.setName("JTextArea1"); //$NON-NLS-1$
			ivjJTextArea1.setRows(3);
			ivjJTextArea1.setColumns(7);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjJTextArea1;
}
/**
 * Return the JTextField1 property value.
 * @return javax.swing.JTextField
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JTextField getJTextField1() {
	if (ivjJTextField1 == null) {
		try {
			ivjJTextField1 = new javax.swing.JTextField();
			ivjJTextField1.setName("JTextField1"); //$NON-NLS-1$
			ivjJTextField1.setText(Messages.getString("JTextField_19")); //$NON-NLS-1$
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjJTextField1;
}
/**
 * Return the JToggleButton1 property value.
 * @return javax.swing.JToggleButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private javax.swing.JToggleButton getJToggleButton1() {
	if (ivjJToggleButton1 == null) {
		try {
			ivjJToggleButton1 = new javax.swing.JToggleButton();
			ivjJToggleButton1.setName("JToggleButton1"); //$NON-NLS-1$
			ivjJToggleButton1.setText(Messages.getString("JToggleButton_21")); //$NON-NLS-1$
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	}
	return ivjJToggleButton1;
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(java.lang.Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	try {
		// user code begin {1}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	}
	// user code begin {2}
	// user code end
}
/**
 * main entrypoint - starts the part when it is run as an application
 * @param args java.lang.String[]
 */
public static void main(java.lang.String[] args) {
	try {
		BasicSwingComponents aBasicSwingComponents;
		aBasicSwingComponents = new BasicSwingComponents();
	} catch (Throwable exception) {
		System.err.println("Exception occurred in main() of java.lang.Object"); //$NON-NLS-1$
		exception.printStackTrace(System.out);
	}
}
}
